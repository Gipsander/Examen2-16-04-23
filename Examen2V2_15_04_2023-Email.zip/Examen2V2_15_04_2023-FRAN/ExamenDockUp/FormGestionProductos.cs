﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;//importante
using ExamenDockUp;
using Newtonsoft.Json;
using Microsoft.Office.Interop.Excel;
using Vender_Bosquejo_2;

namespace borrador
{
    public partial class FormGestionDeProductos : Form
    {
        private string _pathProductos = "";
        public static List<Productos> productos = new List<Productos>();
        public int n = -1;
        public List<Productos> ListaProductos { get { return productos; } set { productos = value; } }
        public string PathProductos { get { return _pathProductos; } set { _pathProductos = value; } }
        public FormGestionDeProductos()
        {
            InitializeComponent();
        }
        private void GuardarProductos()
        {
            string jsonFacturas = JsonConvert.SerializeObject(ListaProductos.ToArray(), Formatting.Indented);
            txtCodigo.Text = ((productos.Count() + 1).ToString()).PadLeft(5, '0');
            File.WriteAllText(_pathProductos, jsonFacturas);
        }
        private void LlenarTablaProductos()
        {
            for (int i = 0; i < productos.Count; i++)
            {
                for (int j = 0; j < dtgvProductos.Columns.Count; j++)
                {
                    if (j == 0) dtgvProductos[j, i].Value = productos[i]._codigo;
                    else if (j == 1) dtgvProductos[j, i].Value = productos[i]._nombre;
                    else if (j == 2) dtgvProductos[j, i].Value = productos[i]._descripcion;
                    else if (j == 3) dtgvProductos[j, i].Value = productos[i]._precio;
                    else if (j == 4) dtgvProductos[j, i].Value = productos[i]._cantidad;
                    else if (j == 5) dtgvProductos[j, i].Value = productos[i]._disponible;
                }
            }
        }
        private void btnAgregarProducto_Click(object sender, EventArgs e)
        {
            try
            {
                string codigo = txtCodigo.Text;
                string nombre = txtNombre.Text;
                double precio;
                string descripcion = txtDescripcion.Text;
                int cantidad = 0;

                //Precio
                if (!double.TryParse(txtPrecio.Text, out precio))
                {
                    throw new Exception("El precio introducido no es válido");
                }
                if (precio < 0)
                {
                    throw new Exception("El Precio Indicado no es valido\nNo se manejan valores negativos");
                }
                if (txtPrecio.Text == null)
                {
                    throw new Exception("El Campo del Precio esta Vacio!");
                }
                //Descripcion
                if (string.IsNullOrEmpty(descripcion))
                {
                    throw new Exception("Descripcion invalida");
                }
                //Cantidad
                if (!int.TryParse(txtCantidad.Text, out cantidad))
                {
                    throw new Exception("La cantidad introducida no es válida");
                }
                if (cantidad < 0)
                {
                    throw new Exception("La Cantidad Indicada no es valida\nNo se manejan valores negativos");
                }
                //Nombre
                if (string.IsNullOrEmpty(nombre))
                {
                    throw new Exception("El Campo del nombre esta vacio!");
                }
                #region Anterior Try Catch
                /*string codigo = txtCodigo.Text;
                string nombre = txtNombre.Text;
                double precio = Convert.ToDouble(txtPrecio.Text);
                string descripcion = txtDescripcion.Text;
                int cantidad = Convert.ToInt32(txtCantidad.Text);*/
                /*if (precio == 0)
                {
                    throw new Exception("El precio no puede ser 0");
                }
                else if (precio < 0)
                {
                    throw new Exception("El precio no puede ser negativo");
                }
                else if (txtPrecio.Text == null)
                {
                    throw new Exception("el precio no puede ser vacio");
                }
                else if (string.IsNullOrEmpty(descripcion) || txtDescripcion.Text == null)
                {
                    throw new Exception("Descripcion invalida");
                }
                else if (cantidad == 0 || cantidad < 0)
                {
                    throw new Exception("Ingrese una cantidad de productos correcta");
                }
                else if (string.IsNullOrEmpty(nombre))
                {
                    throw new Exception("El nombre del producto no puede ser vacio!");
                }*/
                #endregion
                int n = dtgvProductos.Rows.Add();
                Productos prod = new Productos(codigo, nombre, descripcion, cantidad, precio);
                productos.Add(prod);
                MessageBox.Show($"Agregado {txtCodigo.Text};{txtNombre.Text};{txtDescripcion.Text};{txtPrecio.Text};{txtCantidad.Text}");
                txtCodigo.Text = ((productos.Count() + 1).ToString()).PadLeft(5, '0');
                dtgvProductos.Rows[n].Cells[0].Value = codigo;
                dtgvProductos.Rows[n].Cells[1].Value = nombre;
                dtgvProductos.Rows[n].Cells[2].Value = descripcion;
                dtgvProductos.Rows[n].Cells[3].Value = precio + "$";
                dtgvProductos.Rows[n].Cells[4].Value = cantidad;
                dtgvProductos.Rows[n].Cells[5].Value = true;
                GuardarProductos();
                txtPrecio.Clear();
                txtNombre.Clear();
                txtDescripcion.Clear();
                txtCantidad.Clear();
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void dtgvProductos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            n = e.RowIndex; //indice de la seleccion
            
            /*if (n != -1) //condiciono la primera celda : codigo, nombre , descripcion...
            {
                lblform.Text = " ";
            }*/
            //Si la persona selecciona la columna de editar, abriremos dicha ventana
            if (e.ColumnIndex == 6)
            {
                MessageBox.Show("Falta Crear la Ventana para Modificar Productos");
            }
        }

        private void btnEliminarProducto_Click(object sender, EventArgs e)
        {
            try
            {
                if (n != -1 && dtgvProductos.Rows.Count >= 0)
                {                   //reglon//nos eliminala fila
                    if (MessageBox.Show($"Esta Seguro que desea Eliminar al Producto Indicado?\n\n {productos[n].DataEliminar()}", "Confirmacion", MessageBoxButtons.OKCancel, MessageBoxIcon.Information) == DialogResult.OK)
                    {
                        dtgvProductos.Rows.RemoveAt(n);


                        txtCodigo.Text = ((productos.Count() + 1).ToString()).PadLeft(5, '0');
                        productos.Remove(productos[n]);
                    }
                }
                else
                {
                    throw new Exception("No se pueden eliminar más artículos.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);

            }
            GuardarProductos();
        }

        private void btnImportar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Productos Importados");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ExportarExel(dtgvProductos);
            MessageBox.Show("Productos Exportados");
        }
        private void ExportarExel(DataGridView dataDeProductos)
        {
            Microsoft.Office.Interop.Excel.Application Productos = new Microsoft.Office.Interop.Excel.Application();
            
            Productos.Application.Workbooks.Add(true);

            int IndiceDeColumna = 0;
            foreach (DataGridViewColumn col in dataDeProductos.Columns) //Para las columnas 
            {
                IndiceDeColumna++;
                Productos.Cells[1, IndiceDeColumna] = col.Name;
            }

            int IndiceDeFila = 0;
            foreach (DataGridViewRow row in dataDeProductos.Rows)//Para las filas 
            {
                IndiceDeFila++;
                IndiceDeColumna = 0;

                foreach (DataGridViewColumn col in dataDeProductos.Columns) 
                {
                    IndiceDeColumna++;
                    Productos.Cells[IndiceDeFila + 1, IndiceDeColumna] = row.Cells[col.Name].Value;
                }
            }
            Productos.Visible = true;
        }

        private void Form2_Load(object sender, EventArgs e)
        {//using systen.io
            
            /*Con este condicional; al cargarse la ventana se escribe el codigo correspondiente al siguiente
             porducto a crear*/

            if (productos.Count == 0)
            {
                txtCodigo.Text = ("1".PadLeft(5, '0'));
            }
            else
            {
                txtCodigo.Text = ((productos.Count() + 1).ToString()).PadLeft(5, '0');
            }

            //Con este otro se crean las filas necesarias para mostrar los productos que hay

            if (dtgvProductos.Rows.Count == 0 && productos.Count != 0) dtgvProductos.Rows.Add(productos.Count);

            LlenarTablaProductos();
        }

        private void btnRegresar_Click(object sender, EventArgs e)
        {
            
            this.Close();
        }

        private void dtgvProductos_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 5)
            {
                if (Convert.ToBoolean(dtgvProductos[5, n].Value) == true)
                {
                    dtgvProductos[5, n].Value = false;
                    productos[n]._disponible = false;
                }
                else
                {
                    dtgvProductos[5, n].Value = true;
                    productos[n]._disponible = true;
                }
                GuardarProductos();
                MessageBox.Show("Se ha Guardado el Cambio en el Json");
            }
            
        }
    }
}
