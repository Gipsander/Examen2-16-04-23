﻿namespace ExamenDockUp
{
    partial class FormMain
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.BarrasDecoracion = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnVender = new System.Windows.Forms.Button();
            this.btnClientes = new System.Windows.Forms.Button();
            this.pDatosUsuario = new System.Windows.Forms.Panel();
            this.lblCargo = new System.Windows.Forms.Label();
            this.lblNombre = new System.Windows.Forms.Label();
            this.btnCerrarSesion = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.gBoxAdmin = new System.Windows.Forms.GroupBox();
            this.btnEmpresa = new System.Windows.Forms.Button();
            this.btnProductos = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.pbConfiguracion = new System.Windows.Forms.PictureBox();
            this.rtbConfiguracion = new System.Windows.Forms.RichTextBox();
            this.pDatosUsuario.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.gBoxAdmin.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbConfiguracion)).BeginInit();
            this.SuspendLayout();
            // 
            // BarrasDecoracion
            // 
            this.BarrasDecoracion.BackColor = System.Drawing.Color.DarkBlue;
            this.BarrasDecoracion.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.BarrasDecoracion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BarrasDecoracion.Location = new System.Drawing.Point(0, 511);
            this.BarrasDecoracion.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.BarrasDecoracion.Name = "BarrasDecoracion";
            this.BarrasDecoracion.Size = new System.Drawing.Size(732, 18);
            this.BarrasDecoracion.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.DarkBlue;
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(732, 18);
            this.label1.TabIndex = 1;
            // 
            // btnVender
            // 
            this.btnVender.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVender.Location = new System.Drawing.Point(74, 149);
            this.btnVender.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnVender.Name = "btnVender";
            this.btnVender.Size = new System.Drawing.Size(186, 77);
            this.btnVender.TabIndex = 1;
            this.btnVender.Text = "Vender";
            this.btnVender.UseVisualStyleBackColor = true;
            this.btnVender.Click += new System.EventHandler(this.btnVender_Click);
            // 
            // btnClientes
            // 
            this.btnClientes.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClientes.Location = new System.Drawing.Point(72, 342);
            this.btnClientes.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnClientes.Name = "btnClientes";
            this.btnClientes.Size = new System.Drawing.Size(186, 77);
            this.btnClientes.TabIndex = 2;
            this.btnClientes.Text = "Gestion de Clientes";
            this.btnClientes.UseVisualStyleBackColor = true;
            this.btnClientes.Click += new System.EventHandler(this.btnClientes_Click);
            // 
            // pDatosUsuario
            // 
            this.pDatosUsuario.BackColor = System.Drawing.Color.Transparent;
            this.pDatosUsuario.Controls.Add(this.lblCargo);
            this.pDatosUsuario.Controls.Add(this.lblNombre);
            this.pDatosUsuario.Controls.Add(this.btnCerrarSesion);
            this.pDatosUsuario.Controls.Add(this.pictureBox1);
            this.pDatosUsuario.Location = new System.Drawing.Point(309, 371);
            this.pDatosUsuario.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pDatosUsuario.Name = "pDatosUsuario";
            this.pDatosUsuario.Size = new System.Drawing.Size(429, 145);
            this.pDatosUsuario.TabIndex = 9;
            // 
            // lblCargo
            // 
            this.lblCargo.BackColor = System.Drawing.Color.Transparent;
            this.lblCargo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCargo.Location = new System.Drawing.Point(50, 40);
            this.lblCargo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCargo.Name = "lblCargo";
            this.lblCargo.Size = new System.Drawing.Size(202, 35);
            this.lblCargo.TabIndex = 9;
            this.lblCargo.Text = "Cargo del Usuario";
            this.lblCargo.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblNombre
            // 
            this.lblNombre.BackColor = System.Drawing.Color.Transparent;
            this.lblNombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombre.Location = new System.Drawing.Point(45, 5);
            this.lblNombre.Margin = new System.Windows.Forms.Padding(0);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(207, 35);
            this.lblNombre.TabIndex = 8;
            this.lblNombre.Text = "Nombre de Usuario";
            this.lblNombre.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnCerrarSesion
            // 
            this.btnCerrarSesion.BackColor = System.Drawing.Color.Red;
            this.btnCerrarSesion.FlatAppearance.BorderColor = System.Drawing.Color.DarkRed;
            this.btnCerrarSesion.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkRed;
            this.btnCerrarSesion.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCerrarSesion.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCerrarSesion.ForeColor = System.Drawing.Color.White;
            this.btnCerrarSesion.Location = new System.Drawing.Point(108, 95);
            this.btnCerrarSesion.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnCerrarSesion.Name = "btnCerrarSesion";
            this.btnCerrarSesion.Size = new System.Drawing.Size(144, 40);
            this.btnCerrarSesion.TabIndex = 7;
            this.btnCerrarSesion.Text = "Cerrar Sesion";
            this.btnCerrarSesion.UseVisualStyleBackColor = false;
            this.btnCerrarSesion.Click += new System.EventHandler(this.btnCerrarSesion_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = global::ExamenDockUp.Properties.Resources.admin;
            this.pictureBox1.Location = new System.Drawing.Point(261, 5);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(162, 132);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = global::ExamenDockUp.Properties.Resources.Carrito;
            this.pictureBox2.Location = new System.Drawing.Point(100, 42);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(134, 105);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 10;
            this.pictureBox2.TabStop = false;
            // 
            // gBoxAdmin
            // 
            this.gBoxAdmin.BackColor = System.Drawing.Color.Transparent;
            this.gBoxAdmin.Controls.Add(this.btnEmpresa);
            this.gBoxAdmin.Controls.Add(this.btnProductos);
            this.gBoxAdmin.Location = new System.Drawing.Point(411, 35);
            this.gBoxAdmin.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.gBoxAdmin.Name = "gBoxAdmin";
            this.gBoxAdmin.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.gBoxAdmin.Size = new System.Drawing.Size(294, 215);
            this.gBoxAdmin.TabIndex = 3;
            this.gBoxAdmin.TabStop = false;
            this.gBoxAdmin.Text = "Admin";
            // 
            // btnEmpresa
            // 
            this.btnEmpresa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEmpresa.Location = new System.Drawing.Point(43, 115);
            this.btnEmpresa.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnEmpresa.Name = "btnEmpresa";
            this.btnEmpresa.Size = new System.Drawing.Size(213, 91);
            this.btnEmpresa.TabIndex = 4;
            this.btnEmpresa.Text = "Gestion de Datos de Empresa";
            this.btnEmpresa.UseVisualStyleBackColor = true;
            this.btnEmpresa.Click += new System.EventHandler(this.btnEmpresa_Click);
            // 
            // btnProductos
            // 
            this.btnProductos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProductos.Location = new System.Drawing.Point(57, 28);
            this.btnProductos.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnProductos.Name = "btnProductos";
            this.btnProductos.Size = new System.Drawing.Size(186, 77);
            this.btnProductos.TabIndex = 3;
            this.btnProductos.Text = "Gestion de Productos";
            this.btnProductos.UseVisualStyleBackColor = true;
            this.btnProductos.Click += new System.EventHandler(this.btnProductos_Click);
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Lavender;
            this.label2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label2.Location = new System.Drawing.Point(0, 502);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(732, 9);
            this.label2.TabIndex = 12;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Lavender;
            this.label3.Dock = System.Windows.Forms.DockStyle.Top;
            this.label3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label3.Location = new System.Drawing.Point(0, 18);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(732, 9);
            this.label3.TabIndex = 13;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.Lavender;
            this.label4.Dock = System.Windows.Forms.DockStyle.Left;
            this.label4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label4.Location = new System.Drawing.Point(0, 27);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(9, 475);
            this.label4.TabIndex = 14;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.Lavender;
            this.label5.Dock = System.Windows.Forms.DockStyle.Right;
            this.label5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label5.Location = new System.Drawing.Point(723, 27);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(9, 475);
            this.label5.TabIndex = 15;
            // 
            // pbConfiguracion
            // 
            this.pbConfiguracion.BackColor = System.Drawing.Color.Transparent;
            this.pbConfiguracion.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pbConfiguracion.Image = global::ExamenDockUp.Properties.Resources.Configuracion;
            this.pbConfiguracion.Location = new System.Drawing.Point(20, 445);
            this.pbConfiguracion.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pbConfiguracion.Name = "pbConfiguracion";
            this.pbConfiguracion.Size = new System.Drawing.Size(68, 69);
            this.pbConfiguracion.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbConfiguracion.TabIndex = 16;
            this.pbConfiguracion.TabStop = false;
            this.pbConfiguracion.Click += new System.EventHandler(this.rtbConfiguracion_Click);
            // 
            // rtbConfiguracion
            // 
            this.rtbConfiguracion.BackColor = System.Drawing.Color.White;
            this.rtbConfiguracion.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.rtbConfiguracion.Cursor = System.Windows.Forms.Cursors.Hand;
            this.rtbConfiguracion.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbConfiguracion.ForeColor = System.Drawing.Color.MidnightBlue;
            this.rtbConfiguracion.Location = new System.Drawing.Point(96, 465);
            this.rtbConfiguracion.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.rtbConfiguracion.Name = "rtbConfiguracion";
            this.rtbConfiguracion.ReadOnly = true;
            this.rtbConfiguracion.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.rtbConfiguracion.Size = new System.Drawing.Size(116, 45);
            this.rtbConfiguracion.TabIndex = 6;
            this.rtbConfiguracion.TabStop = false;
            this.rtbConfiguracion.Text = "Configuracion de Usuario";
            this.rtbConfiguracion.Click += new System.EventHandler(this.rtbConfiguracion_Click);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::ExamenDockUp.Properties.Resources.BackgroundLogo;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(732, 529);
            this.Controls.Add(this.rtbConfiguracion);
            this.Controls.Add(this.pbConfiguracion);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.gBoxAdmin);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pDatosUsuario);
            this.Controls.Add(this.btnClientes);
            this.Controls.Add(this.btnVender);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BarrasDecoracion);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MaximumSize = new System.Drawing.Size(754, 585);
            this.MinimumSize = new System.Drawing.Size(754, 585);
            this.Name = "FormMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Main";
            this.Load += new System.EventHandler(this.FormMain_Load);
            this.pDatosUsuario.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.gBoxAdmin.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbConfiguracion)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label BarrasDecoracion;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnVender;
        private System.Windows.Forms.Button btnClientes;
        private System.Windows.Forms.Panel pDatosUsuario;
        private System.Windows.Forms.Label lblCargo;
        private System.Windows.Forms.Label lblNombre;
        private System.Windows.Forms.Button btnCerrarSesion;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.GroupBox gBoxAdmin;
        private System.Windows.Forms.Button btnEmpresa;
        private System.Windows.Forms.Button btnProductos;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pbConfiguracion;
        private System.Windows.Forms.RichTextBox rtbConfiguracion;
    }
}

