﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using borrador;
using DatosEmpresa;
using Newtonsoft.Json;
using System.Collections;
using System.IO;
using ExamenDockUp;

namespace Vender_Bosquejo_2
{
    public partial class FormAgregarProducto : Form
    {
        private int n = -1;
        private int _cantidadSeleccionada = 0;
        private List<Productos> _compras = new List<Productos>(); //Carrito del Comprador
        private List<Productos> _productos = new List<Productos>(); //Productos Disponibles
        private DataGridView CopiaPreview = new DataGridView();
        public int CantidadSeleccionada { get { return _cantidadSeleccionada; } set { _cantidadSeleccionada=value; } }
        public List<Productos> Productos { get { return _productos; } set { _productos = value; } }
        public List<Productos> ComprasCliente { get { return _compras; } set { _compras = value; } }
        public DataGridView DataGrid { get { return CopiaPreview; } set { CopiaPreview = value; } }
        public FormAgregarProducto()
        {
            InitializeComponent();
            Location = new Point(Screen.PrimaryScreen.WorkingArea.Width - Width, 0);
        }
        private void btnRegresar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void FormAgregarProducto_Load(object sender, EventArgs e)
        {
            n = -1;
            lblPosicion.Visible = false;
            dtgvListaDeProductos.Rows.Clear();
            if (Productos.Count != 0) dtgvListaDeProductos.Rows.Add(Productos.Count);
            if (_productos.Count > 0)
            {
                for (int i = 0; i < Productos.Count; i++)
                {
                    for (int j = 0; j < dtgvListaDeProductos.Columns.Count; j++)
                    {
                        if (j == 0) dtgvListaDeProductos[j, i].Value = Productos[i]._codigo;
                        else if (j == 1) dtgvListaDeProductos[j, i].Value = Productos[i]._nombre;
                        else if (j == 2) dtgvListaDeProductos[j, i].Value = Productos[i]._descripcion;
                        else if (j == 3) dtgvListaDeProductos[j, i].Value = Productos[i]._precio;
                        else if (j == 4) dtgvListaDeProductos[j, i].Value = Productos[i]._cantidad;
                    }
                }
            }
            else MessageBox.Show("No existe Producto alguno para mostrar", "Inexistencia de Productos", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }
        private void btnAgregar_Click(object sender, EventArgs e)
        {
            if(n != -1)
            {
                try
                {
                    if (string.IsNullOrEmpty(txtCantidad.Text)) { throw new Exception("El campo de cantidad no puede quedar vacio"); }
                    if (!int.TryParse(txtCantidad.Text, out _cantidadSeleccionada))
                    {
                        throw new Exception("El formato de la Cantidad es Incorrecto.\nNo se permite el uso de Caracteres");
                    }
                    if (_cantidadSeleccionada <= 0) { throw new Exception("No puede aniadir una cantidad que no existe"); }

                    _compras.Add(_productos[n]);
                    int aux = CopiaPreview.Rows.Add();
                    CopiaPreview[0, aux].Value = _productos[n]._codigo;
                    CopiaPreview[1, aux].Value = _productos[n]._nombre;
                    CopiaPreview[2, aux].Value = _productos[n]._descripcion;
                    CopiaPreview[3, aux].Value = _productos[n]._precio;
                    CopiaPreview[4, aux].Value = _cantidadSeleccionada;
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
            else MessageBox.Show("No ha Seleccionado Producto Alguno a Agregar","Por Favor Seleccione Algun Producto",MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
        }

        private void dtgvListaDeProductos_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            n = e.RowIndex;
            lblPosicion.Visible = true;
            lblPosicion.Text = $"Numero de Fila del Producto Seleccionado: {e.RowIndex + 1}";
        }

        private void lblRegresar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            if (n != -1)
            {
                _compras.Add(_productos[n]);
                _cantidadSeleccionada = Convert.ToInt32(txtCantidad.Text);
                int aux = CopiaPreview.Rows.Add();
                CopiaPreview[0, aux].Value = _productos[n]._codigo;
                CopiaPreview[1, aux].Value = _productos[n]._nombre;
                CopiaPreview[2, aux].Value = _productos[n]._descripcion;
                CopiaPreview[3, aux].Value = _productos[n]._precio;
                CopiaPreview[4, aux].Value = _cantidadSeleccionada;
            }
            else MessageBox.Show("No ha Seleccionado Producto Alguno a Agregar", "Por Favor Seleccione Algun Producto", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
    }
}
