using Newtonsoft.Json;
using System;
using System.Data;
using System.Drawing.Drawing2D;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExamenDockUp;

namespace DatosEmpresa
{
    public partial class FormGestionDatosClientes : Form
    {
        private string _pathClientes = "";
        private int aux = -1;
        private List<Cliente> _datosCliente = new List<Cliente>();
        private FormAgregarCliente Agregar = new FormAgregarCliente();
        public FormGestionDatosClientes()
        {
            InitializeComponent();
        }
        public string PathClientes { set { _pathClientes = value; } get { return _pathClientes; } }
        public List<Cliente> ListaClientes { get { return _datosCliente; } set { _datosCliente = value; } }
        private void GuardarClientes()
        {
            string empleadosJson = JsonConvert.SerializeObject(_datosCliente.ToArray(), Formatting.Indented);
            File.WriteAllText(_pathClientes, empleadosJson);
        }
        private void ActualizarTabla()
        {
            dtgvClientes.Rows.Clear();

            if (_datosCliente.Count > 0) dtgvClientes.Rows.Add(_datosCliente.Count);

            LlenarTablaClientes();
        }
        private void LlenarTablaClientes()
        {
            if (_datosCliente.Count > 0)
            {
                for (int i = 0; i < _datosCliente.Count; i++)
                {
                    for (int j = 0; j < dtgvClientes.Columns.Count; j++)
                    {
                        if (j == 0) dtgvClientes[j, i].Value = _datosCliente[i].Nombre;
                        else if (j == 1) dtgvClientes[j, i].Value = _datosCliente[i].Apellido;
                        else if (j == 2) dtgvClientes[j, i].Value = _datosCliente[i].Cedula;
                        else if (j == 3) dtgvClientes[j, i].Value = _datosCliente[i].NumeroDeTlf;
                    }
                }
            }
        }
        private void FormGestionClientes_Load(object sender, EventArgs e)
        {
            Agregar.PathClientes = _pathClientes;
            Agregar.ListaClientes = _datosCliente;
            lblPosicion.Visible = false;
            aux = -1;

            object imagen = @"editar.png";
            dtgvClientes.Rows.Add(imagen);

            ActualizarTabla();
        }
        private void btnAgregarCliente_Click(object sender, EventArgs e)
        {
            //Con el Index = -1 le damos a entender a la siguiente ventana que va a tener que 
            //Crear un nuevo Cliente

            Agregar.Index = -1;
            Agregar.ShowDialog();

            ActualizarTabla();
        }
        private void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                if (aux != -1 && dtgvClientes.Rows.Count > 0)
                {
                    if(MessageBox.Show($"Esta Seguro que desea Eliminar al Cliente Indicado?\n\n {_datosCliente[aux].DataEliminar()}","Confirmacion",MessageBoxButtons.OKCancel,MessageBoxIcon.Information) == DialogResult.OK)
                    {
                        dtgvClientes.Rows.RemoveAt(aux);
                        _datosCliente.RemoveAt(aux);
                        GuardarClientes();
                        if (aux > -1)
                        {
                            aux--;
                            lblPosicion.Text = $"Numero de Fila del Cliente Seleccionado: {aux + 1}";
                        }
                        if (aux + 1 == 0) lblPosicion.Visible = false;
                    }
                }
                else if(aux == -1)
                {
                    throw new Exception("No se ha Seleccionado Ningun Cliente a Eliminar");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }
        private void dtgvEmpleados_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            aux = e.RowIndex;
            lblPosicion.Visible = true;
            lblPosicion.Text = $"Numero de Fila del Cliente Seleccionado: {e.RowIndex+1}";

            //Si la persona selecciona la columna de editar, abriremos dicha ventana
            if (e.ColumnIndex == 4) 
            {
                Agregar.Index = aux;
                Agregar.ShowDialog();
                ActualizarTabla();
            }
        }

        private void PicRegresar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}